<?php
include 'config.php';
$id = $_GET['id'];
$conn->query("DELETE FROM covid WHERE id='id'");
echo "<script>alert('Data Berhasil terhapus');</script>";
echo "<script>location='?page=view';</script>";
?>