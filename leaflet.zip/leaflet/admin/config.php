<?php 
session_start();
$conn = new mysqli("localhost", "root", "", "leaflet") or die("Koneksi Error");
?>