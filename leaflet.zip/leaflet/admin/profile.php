<div class="container">
	<div class="row">
		<div class="card col-md-12">
			<div class="card-body">
				<h3>Sejarah</h3>
				<p>Sejarah perkembangan rumah sakit di Indonesia pertama sekali didirikan oleh VOC tahun 1626 dan kemudian juga oleh tentara Inggris pada zaman Raffles terutama ditujukan untuk melayani anggota militer beserta keluarganya secara gratis. Jika masyarakat pribumi memerlukan pertolongan, kepada mereka juga diberikan pelayanan gratis. Hal ini berlanjut dengan rumah sakit-rumah sakit yang didirikan oleh kelompok agama. Sikap karitatif ini juga diteruskan oleh rumah sakit CBZ di Jakarta. Rumah sakit ini juga tidak memungut bayaran pada orang miskin dan gelandangan yang memerlukan pertolongan. Semua ini telah menanamkan kesan yang mendalam di kalangan masyarakat pribumi bahwa pelayanan penyembuhan di rumah sakit adalah gratis. Mereka tidak mengetahui bahwa sejak zaman VOC, orang Eropa yang berobat di rumah sakit VOC (kecuali tentara dan keluarganya) ditarik bayaran termasuk pegawai VOC.</p>
				<div class="cmsmasters_text">
					<h3> Visi dan Misi</h3>
					<p><strong>Visi</strong></p>
					<p><li>Menjadi rumah sakit pilihan dengan menyediakan pelayanan kesehatan yang handal & berkualitas</li></p>
					<p><strong>Misi</strong></p>
					<li>Memberikan pelayanan kesehatan dengan tulus hati dengan berprilaku profesional, berkualitas, & dengan biaya yang efektif.</li>
      <li>Menciptakan kesadaran masyarakat akan gaya hidup sehat.</li>
      <li>Menciptakan lingkungan kerja yang menyenangkan & menantang.</li>
	  <div class="cmsmasters_text">
	  <h3></h3>
	  <p><h3>Tentang COVID-19</h3></p>
	  <p><strong>Apa Itu COVID-19?</strong></p>
					<p>Pneumonia Coronavirus Disease 2019 atau COVID-19 adalah penyakit peradangan paru yang disebabkan oleh Severe Acute Respiratory Syndrome Coronavirus 2 (SARS-CoV-2). Gejala klinis yang muncul beragam, mulai dari seperti gejala flu biasa (batuk, pilek, nyeri tenggorok, nyeri otot, nyeri kepala) sampai yang berkomplikasi berat (pneumonia atau sepsis).</p>
					<p><strong>Bagaimana COVID-19 Menular?</strong></p>
	 <p>Cara penularan SARS-CoV-2 penyebab COVID-19 ialah melalui kontak dengan droplet saluran napas penderita. Droplet merupakan partikel kecil dari mulut penderita yang mengandung kuman penyakit, yang dihasilkan pada saat batuk, bersin, atau berbicara. Droplet dapat melewati sampai jarak tertentu (biasanya 1 meter). Droplet bisa menempel di pakaian atau benda di sekitar penderita pada saat batuk atau bersin. Namun, partikel droplet cukup besar sehingga tidak akan bertahan atau mengendap di udara dalam waktu yang lama. Oleh karena itu, orang yang sedang sakit, diwajibkan untuk menggunakan masker untuk mencegah penyebaran droplet. Untuk penularan melalui makanan, sampai saat ini belum ada bukti ilmiahnya.</p>
	 <p><strong>Lakukan Hal Berikut Ini Jika Anda Mengalami Gejala Mirip COVID-19</strong></p>
					<li>Kenakan masker (tipe masker bedah), dan ganti secara berkala, agar tidak menular ke orang lain.</li>
      <li>Batasi menerima tamu di rumah, hindari kontak langsung dengan tamu untuk mencegah penyebaran virus yang lebih luas.</li>
      <li>Tinggal di rumah dan jaga jarak dengan orang lain.</li>
<li>Minta bantuan teman, anggota keluarga, atau layanan jasa lain untuk menyelesaikan urusan di luar rumah.</li>
<li>Lakukan ini semua selama 14 hari untuk membantu mengurangi penyebaran virus</li>
<div class="cmsmasters_text">
	  <p><h3></h3></p>
	  <p><strong>Penanganan Pasien COVID-19</strong></p>
	  <p>Saat ini belum ada obat khusus untuk pasien dengan COVID-19. Perawatan yang tersedia saat ini bertujuan untuk meringankan gejala. Anda harus tetap terisolasi dari orang lain sampai Anda benar-benar pulih.</p>
					</div>
			</div>
		</div>
	</div>
</div>
