-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2020 at 04:00 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leaflet`
--

-- --------------------------------------------------------

--
-- Table structure for table `covid`
--

CREATE TABLE `covid` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `alamat` text,
  `lat` float(9,7) DEFAULT NULL,
  `lng` float(9,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `covid`
--

INSERT INTO `covid` (`id`, `nama`, `kecamatan`, `alamat`, `lat`, `lng`) VALUES
(1, 'Dinkes Kabupaten Batang', 'Jl. Jendral Sudirman No.417', 'Batang', -69.0579987, 1.097000),
(2, 'RSUD Batang', 'Jl. Dr.Sutomo No.42', 'Batang', -69.1470032, 1.097000),
(3, 'RS QIM Batang', 'Jl. Yudistira', 'Batang', -69.1689987, 1.097000),
(4, 'RSUD Limpung', 'Jalan Dr. Sutomo No.17 A', 'Limpung', -70.1709976, 1.099000),
(5, 'Puskesmas Banyuputih', 'Jl. Raya Banyuputih No.49', 'Banyuputih', -69.7220001, 1.099000),
(6, 'Puskesmas Batang 1', 'Jl. Dr.Cipto No.34', 'Batang', -6.9099998, 1.097000),
(7, 'Puskesmas Wonotunggal', 'Jl. Raya Wonotunggal', 'Wonotunggal', -69.9489975, 1.097000),
(8, 'Puskesmas Bandar 1', 'Jl. Raya Wonokerto', 'Bandar', -70.2880020, 1.097000),
(9, 'Puskesmas Bandar 2', 'Jl. Raya Simpar', 'Bandar', -69.8980026, 1.097000),
(10, 'Puskesmas Blado 1', 'Jl. Raya Blado', 'Blado', -70.6910019, 1.098000),
(11, 'Puskesmas Blado 2', 'Jl. Raya Kambangan', 'Blado', -100.0000000, 1.098000),
(12, 'Puskesmas Reban', 'Jl. Raya Reban', 'Reban', -70.8050003, 109.871002),
(13, 'Puskesmas Bawang', 'Jl. Klawen', 'Bawang', -7.1050000, 1.099000),
(14, 'Puskesmas Tersono', 'Jl. Pahala', 'Tersono', -70.2389984, 109.963997),
(15, 'Puskesmas Gringsing 1', 'Jl. Raya Semarang - Batang No.203', 'Gringsing', -69.6989975, 1.100000),
(16, 'Puskesmas Gringsing 2', 'Jl. Raya Subah', 'Gringsing', -69.7689972, 1.099000),
(17, 'Puskesmas Limpung', 'Jl. Wesi Aji', 'Limpung', -70.1149979, 1.099000),
(18, 'Puskesmas Subah', 'Jl. Raya Subah', 'Subah', -69.7139969, 1.098000),
(19, 'Puskesmas Pecalungan', 'Jl. Raya Pecalungan', 'Pecalungan', -70.1660004, 1.098000),
(20, 'Puskesmas Tulis', 'Jl. Kaliboyo 1', 'Tulis', -69.4909973, 1.098000),
(21, 'Puskesmas Kandeman', 'Jalan Raya Semarang - Batang No.525', 'Kandeman', -69.3300018, 1.097000),
(22, 'Puskesmas Batang 2', 'Jl. RE Martadinata No.145', 'Batang', -69.0130005, 1.097000),
(23, 'Puskesmas Batang 3', 'Jl. Pemuda No.184', 'Batang', -69.4749985, 109.737999),
(24, 'Puskesmas Batang 4', 'Randu, Denasri Wetan', 'Batang', -68.9509964, 1.097000),
(25, 'Puskesmas Warungasem', 'Jl. Raya Warungasem No.6', 'Warungasem', -69.3759995, 1.096000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `username`, `password`, `level`, `ket`) VALUES
(1, 'admin', 'admin', 1, 'admin'),
(2, 'user', 'user', 2, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `covid`
--
ALTER TABLE `covid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
