<div class="container">
	<div class="row">
		<div class="col-md-12 peta leaflet-container leaflet-touch leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom" id="mapid"> </div>
	</div>
</div>